USE Tienda_online;
-- muestra clientes con productos pendientes y total de compras 

SELECT c.nombre AS cliente, -- toma el nombre cliente desde la tabla clientes
       c.correo,            -- accede al correo
	   c.telefono,          -- accede al telefono 
       sum(dp.cantidad * dp.precio_unitario) AS total_pendiente -- suma el subtotal del cliente y al final se suma para que de el total 
FROM Clientes c             -- tabla clientes por referencia c
INNER JOIN Pedidos p ON c.id_cliente = p.id_cliente   -- une las dos tablas para clientes con al menos un pedido 
INNER JOIN Detalles_pedido dp ON p.id_pedido = dp.id_pedido -- une las dos tablas que accede a la cantidad y precio del pedido
WHERE p.estado = 'pendiente'   -- sentencia que solo tomara encuenta los que se encuentren pendiente 
GROUP BY c.id_cliente, c.nombre, c.correo, c.telefono   -- agrupa los clientes 
ORDER BY total_pendiente DESC; -- ordena los pendientes y el total de mayor a menor 
