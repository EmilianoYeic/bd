USE Tienda_online;

-- stored procedure 5 

DELIMITER $$

CREATE PROCEDURE EliminaActualiza(
    IN id_producto INT,
    OUT promedio FLOAT
)
BEGIN
    DELETE 
    FROM Resenias -- elimina resenias que tengan el mismo id
    WHERE id_producto = id_producto;

    SELECT IFNULL(AVG(calificacion), 0) -- calcula el promedio de calificaciones de las resenias 
    INTO promedio -- si np hay resenias devuelve 0
    FROM Resenias -- accede a la tabla resenias
    WHERE id_producto = p_id_producto; 
END $$
