USE Tienda_online;
-- Lista de productos disponibles por categoria y ordenados por precio

SELECT c.nombre AS categoria, -- toma el nombre de la categoria desde la tabla categorias
       p.nombre AS producto, -- toma el nombre del producto desde la tabla productos
       p.precio, -- accede directamente al precio
       p.stock  -- acede directamente al stock
FROM Productos p  -- tabla productos por referencia p
INNER JOIN Categorias c ON p.id_categoria = c.id_categoria -- une tablas producto con categorias
WHERE p.stock > 0  -- sentencia que muestra stock disponible osea mas de 0
ORDER BY c.nombre, p.precio ASC; -- ordena el nombre de la categoria y el precio del producto de menor a mayor 

