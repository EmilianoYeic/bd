USE Tienda_online;

-- stored procedure 6 

DELIMITER $$

CREATE PROCEDURE AgregarProducto(
    IN p_nombre VARCHAR(30),
    IN p_descripcion VARCHAR(100),
    IN p_precio FLOAT,
    IN p_stock INT,
    IN p_id_categoria INT
)
BEGIN
    DECLARE existe INT; -- Variable local para saber si el producto existe 

    SELECT COUNT(*) INTO existe -- busca si hay productos con el mismo nombre y categoria
    FROM Productos -- accede a productos
    WHERE nombre = p_nombre AND id_categoria = p_id_categoria;

    IF 
		existe > 0 THEN -- si existe lanza un errror 
        SIGNAL SQLSTATE '45000'  -- genera el estado de error, el numero es necesario que el cliente sepa el error
        SET MESSAGE_TEXT = 'El producto ya existe ';
    ELSE
        INSERT INTO Productos(nombre, descripcion, precio, stock, id_categoria) -- inserta el nuevo producto  
        VALUES (p_nombre, p_descripcion, p_precio, p_stock, p_id_categoria); -- intercambia valores
    END IF;
END $$

