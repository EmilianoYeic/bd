USE Tienda_online;

-- stored procedure 8

DELIMITER $$

CREATE PROCEDURE ReporteBajo()
BEGIN
    SELECT -- lista del producto
        p.id_producto,
        p.nombre AS nombre_producto,
        p.descripcion,
        p.stock,
        c.nombre AS categoria -- nombre de la categoria desde la categoria
    FROM Productos p -- accede a productos con representacion p
    INNER JOIN Categorias c ON p.id_categoria = c.id_categoria -- une tablas con categoria para que de el nombre 
    WHERE p.stock < 5 -- sentencia con menos de 5 productos en stock
    ORDER BY p.stock ASC; -- ordena productos de menor a mayor stock
END $$
