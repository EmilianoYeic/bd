USE Tienda_online;
CREATE INDEX idx_producto_nombre ON productos(nombre);
CREATE INDEX idx_producto_categoria ON productos(id_categoria);
CREATE INDEX idx_pedidos_cliente ON pedidos(id_cliente);
CREATE INDEX idx_resenias_id_producto ON Resenias(id_producto);

-- Estos index sirven para que las busquedas sean mas rapidas, sin la necesidad de que se busque por toda la base de datos,
-- solamente ingresa al campo mencionado y realiza la busqueda 