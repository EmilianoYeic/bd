USE Tienda_online;

INSERT INTO Clientes (nombre, correo, telefono, direccion) VALUES
('Martin', 'martin.sanchez@gmail.com', 5588374926, 'calle del misterio 3 con AV.Torres'),
('Juana', 'Juana.gutierres@hotmail.com', 5623841093, 'Av.San Bernage NO.9'),
('Carlos', 'carlos.diaz@gmail.com', 5534572900, 'Av.San angel NO.16'),
('Ricardo', 'ricardo.perez@gmail.com', 5699274180, 'calle 9 con calle 34'),
('Maria', 'maria.robles@hotmail.com', 5596774100, 'Av. Santa Lucia NO.24'),
('Nayeli', 'nayeli.angeles@gmail.com', 5622980055, 'Donceles 92'),
('Sebastian', 'sebastian.santana@gmail.com', 5562338222, 'Insurgentes 11'),
('Emiliano', 'emiliano.olmedo@gmail.com', 5616649473, 'Av. de los cedros 14'),
('Rodrigo', 'rodrigo.mendez@hotmail.com', 5500348845, 'Bolivar 65'),
('Monica', 'monica.herrera@gmail.com', 5531116632, 'Av. del rey 92'),
('Fernando', 'fernando.nava@gmail.com', 5629996344, 'Tianguillo 13'),
('Alejandra', 'alejandra.guzman@gmail.com', 5593347622, 'Las lomas 88'),
('Fernanda', 'fernanda.lopez@hotmail.com', 5600813766, 'Las cruces 44'),
('Jesus', 'jesus.pineda@gmail.com', 5534448900, 'La papa 67'),
('Raul', 'raul.rodriguez2gmail.com', 5634009029, 'Av. Genova 33'),
('Daniela', 'daniela.romero@hotmail.com', 5655249833, 'Melchor 10'),
('Diego', 'diego.bautista@gmail.com', 5593773111, 'Av. navidad 3'),
('Felipe', 'felipe.calderon@gmail.com', 5600221145, 'Victoria 78'),
('Catalina', 'catalina.moreno@gmail.com', 5549229989, 'Convento 88'),
('jonathan', 'jonathan.martinez@hotmail.com', 5611342121, 'Tacuba 44');

INSERT INTO Categorias (nombre, descripcion) VALUES 
('Alimentos', 'alimentos precesados, frescos o enlatados, bebidas'),
('Salud', 'Medicina, suplementos'),
('Cuidado personal', 'higiene, bienestar'),
('Ropa y accesorios', 'prendas, calzado y accesorios'),
('Hogar', 'accesorios, muebles y utencilios'),
('Ferreteria', 'materiales, herramientas y reparacion'),
('Juguetes', 'juegos, objetos de diversion'),
('Papeleria', 'material y libros'),
('Electronica', 'todo tipo de gadgets'),
('Animales', 'alimento, accesorios, cuidado');


INSERT INTO Productos (nombre, descripcion, precio, stock, id_categoria) VALUES 

('cepillo de dientes', 'Material reciclado con cerdas de nylon suaves y medias', 20.00, 2, 3),
('shampo anticaspa', 'controla caída de cabello y caspa 1 litro', 60.00, 4, 3),
('crema facial', 'hidratación con gel de sábila 255 ml', 100.00, 4, 3), 

('martillo', 'resistente', 150.00, 2, 6),
('faja de seguridad', 'material ajustable de elastano', 250.00, 4, 6),
('guantes de trabajo', 'carnaza flexible', 149.00, 5, 6),

('nuggets de pescado', 'precocidos y condimentados 500 gramos', 80.00, 5, 1),
('salchicha asadera', 'precocidas y rellenas de queso, 800 gramos', 119.00, 70, 1),
('sopa instantánea', 'contiene setas y verduras deshidratadas', 35.00, 90, 1),

('cuaderno cuadriculado', 'fabricado con material reciclado 100 hojas', 53.00, 230, 8),
('mochila', 'material repelente al agua', 800.00, 1, 8),
('lapicero', 'material de aluminio incluye 1 cartucho', 300.00, 140, 8),

('tenis deportivos', 'material transpirable y antiderrapante', 1500.00, 34, 4),
('jeans azules', 'material elástico y ajustable', 700.00, 56, 4),
('camisa de cuadros', 'material poliéster y algodón', 500.00, 23, 4),

('batería portátil', 'capacidad 4400mah incluye tres puertos usb', 500.00, 34, 9),
('disco duro externo', 'material de aluminio con capacidad de 1 terabyte', 1200.00, 67, 9),
('mouse inalámbrico', 'incluye luces led y cargador de batería', 630.00, 38, 9),

('collar para perro', 'material ajustable y resistente', 160.00, 60, 10),
('correa para perro', 'material resistente y flexible 1.5 metros', 198.00, 35, 10),
('colchón para mascotas', 'colchón rectangular dimensiones 50cm x 60cm y 18 cm', 400.00, 55, 10),

('suplemento de fibra', 'elaborado con insumos naturales nopal y linaza', 75.00, 34, 2),
('jarabe para la tos', 'elaborado con propóleo y eucalipto', 89.00, 45, 2),
('suplemento de proteína', 'proteína adicionada con omega 3 600 gramos', 389.00, 25, 2),

('lámpara led inteligente', 'compatible con aplicación para iOS y Android', 200.00, 44, 2),
('mesa de jardín', 'Cuenta con sombrilla y 4 sillas plegables materiales hierro y textil', 3700.00, 24, 5),
('sofá cama', 'material resistente acabado terciopelo, dimensión 180 x 190 x 85', 10997.00, 12, 5),

('bicicleta', 'bicicleta r29 con 7 velocidades y marco de aluminio', 7000.00, 26, 7),
('balón de fútbol', 'tamaño 5 con costura reforzada', 380.00, 78, 7),
('consola de juegos retro', 'incluye 2 mandos 500 juegos con entrada hdmi y memoria de 64 gb', 573.00, 3, 7);


INSERT INTO Pedidos (fecha_pedido, estado, id_cliente) VALUES

('2025-06-05', 'En preparación', 1),
('2025-06-08', 'Entregado', 2),
('2025-06-14', 'En tránsito', 3),
('2025-06-14', 'En camino', 4),
('2025-06-15', 'pendiente', 5),
('2025-06-19', 'En tránsito', 6),
('2025-06-24', 'En preparación', 7), 
('2025-07-03', 'En camino', 8), 
('2025-07-05', 'pendiente', 9),
('2025-07-05', 'pendiente', 9),
('2025-07-05', 'pendiente', 9),
('2025-07-05', 'pendiente', 9),
('2025-07-05', 'pendiente', 9),
('2025-07-05', 'pendiente', 9),
('2025-07-10', 'entregado', 10), 
('2025-07-11', 'En camino', 11),
('2025-07-12', 'pendiente', 12),
('2025-07-16', 'En tránsito', 13),
('2025-07-17', 'En camino', 14), 
('2025-07-17', 'pendiente', 15),
('2025-07-18', 'Entregado', 16),
('2025-07-19', 'En tránsito', 17),
('2025-07-20', 'pendiente', 18),
('2025-07-25', 'cancelado', 19),
('2025-07-27', 'En tránsito', 20);


INSERT INTO Detalles_pedido (cantidad, precio_unitario, id_pedido, id_producto) VALUES

(5, 20, 1, 1),
(4,100, 2, 3),
(3, 80, 3, 7),
(1,573, 4, 30),
(1,380, 5, 19),
(1,1500, 6, 13),
(1,700, 7, 14),
(1,10997, 8, 27),
(1,500,9,16),
(1,630,10,18),
(2,60,11,2),
(1,250,12,5),
(1,400,13,21),
(1,389,14,24),
(1,380,15,29),
(1,7000,16,28),
(1,150,17,4),
(1,700,18,11),
(1,300,19,12),
(5,53,20,10),
(2,200,1,25),
(1,3700,2,26),
(1,1200,3,17),
(3,35,4,9),
(2,89,5,23);


INSERT INTO Resenias (calificacion, comentario, fecha, id_cliente, id_producto) VALUES 

(4, 'excelente producto', '2025-06-08', 1, 1),
(5, 'llegó rápido y en perfectas condiciones', '2025-06-16', 2, 2), 
(3, 'buen producto', '2025-06-14', 3, 3),
(3, 'cumple con lo que promete', '2025-06-19', 4, 4),
(5, 'ideal para lo que necesitaba', '2025-06-28', 5, 5),
(4, 'excelente', '2025-06-19', 6, 6),
(3, 'Buen precio', '2025-06-28', 7, 7),
(3, 'buena calidad', '2025-07-09', 8, 8),
(4, 'volvería a comprarlo', '2025-07-11', 9, 9), 
(4, 'superó mis expectativas', '2025-07-18', 10, 10);


