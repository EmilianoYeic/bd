USE Tienda_online;

-- stored procedure 4

DELIMITER $$

CREATE PROCEDURE CambiarEstado(
    IN pedido_id INT,
    IN nuevo_estado VARCHAR(50)
)
BEGIN
    DECLARE existe INT; -- variable local para guardar la existencia
    
    SELECT COUNT(*) INTO existe -- cuenta cuantos pedidos existen con este id
    FROM Pedidos
    WHERE id_pedido = pedido_id;

    IF 
        existe = 0 THEN -- si es cero, no hay ningun pedido con este id
        SIGNAL SQLSTATE '45000' -- genera el estado de error, el numero es necesario que el cliente sepa el error
        SET MESSAGE_TEXT = 'El pedido no existe';
    ELSE 
        UPDATE Pedidos -- si es mayor a cero, significa que existe 
        SET estado = nuevo_estado -- actualiza el valor del pedido 
        WHERE id_pedido = pedido_id;
    END IF;
END $$

