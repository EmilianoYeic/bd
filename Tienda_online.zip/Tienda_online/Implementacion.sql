CREATE DATABASE IF NOT EXISTS Tienda_online;
USE Tienda_online;
DROP TABLE IF EXISTS Detalles_pedido;
DROP TABLE IF EXISTS Resenias;
DROP TABLE IF EXISTS Pedidos;
DROP TABLE IF EXISTS Productos;
DROP TABLE IF EXISTS Clientes;
DROP TABLE IF EXISTS Categorias;


CREATE TABLE Clientes (
  id_cliente INT PRIMARY KEY AUTO_INCREMENT NOT NULL, 
  nombre VARCHAR(30),
  correo VARCHAR(30) UNIQUE NOT NULL,
  telefono VARCHAR (15),
  direccion VARCHAR(100)
);

CREATE TABLE Categorias (
  id_categoria INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
  nombre VARCHAR(30),
  descripcion VARCHAR(100)
);


CREATE TABLE Productos (
  id_producto INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
  nombre VARCHAR(30),
  descripcion VARCHAR(100),
  precio FLOAT NOT NULL DEFAULT 0,
  stock INT NOT NULL CHECK (stock >= 0),
  id_categoria INT NOT NULL,
  FOREIGN KEY (id_categoria) REFERENCES Categorias(id_categoria)
);

CREATE TABLE Pedidos (
  id_pedido INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
  fecha_pedido DATE, 
  estado VARCHAR(50),
  id_cliente INT NOT NULL,
  FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente)
);

CREATE TABLE Detalles_pedido (
  id_detalle INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
  cantidad INT NOT NULL CHECK (cantidad >= 0),
  precio_unitario FLOAT,
  id_pedido INT NOT NULL,
  id_producto INT NOT NULL,
  FOREIGN KEY (id_pedido) REFERENCES Pedidos(id_pedido),
  FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

CREATE TABLE Resenias (
    id_resenia INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    calificacion INT CHECK (calificacion BETWEEN 1 AND 5),
    comentario VARCHAR (1000),
    fecha DATE, 
    id_cliente INT NOT NULL,
    id_producto INT NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente),
    FOREIGN KEY (id_producto) REFERENCES Productos(id_producto)
);

