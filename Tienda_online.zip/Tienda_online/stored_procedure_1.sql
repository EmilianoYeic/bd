USE Tienda_online;

-- stored procedure 1 

DELIMITER $$

CREATE PROCEDURE RegistraPedido(
    IN cliente_id INT,
    IN producto_id INT,
    IN cantidad INT,
    IN precio_unitario FLOAT
)
BEGIN
    DECLARE pendientes INT; -- declaro nueva variable para los pedidos pendientes 
    DECLARE stockDisponible INT; -- nueva variable para stock disponible 

    SELECT COUNT(*) INTO pendientes -- cuenta pedidos pendientes del cliente 
    FROM Pedidos -- accede a tabla pedidos 
    WHERE id_cliente = cliente_id AND estado = 'pendiente'; -- guarda los pendientes del cliente

    SELECT stock INTO stockDisponible  -- selecciona el stock actual y lo guarda a stockDisponible
    FROM Productos -- accede a Productos 
    WHERE id_producto = producto_id; -- actualiza el nuevo producto id

    -- realice estas dos condiciones para que si el cliente tiene mas de 5 pendientes, mande error de que tiene mas
    -- pero si tiene menos de 5 pendientes salta la primera condicion, y si no hay stock suficiente tambien manda 
    -- error de que ya no hay stock, finalmente
    -- si cumple las 2 condiciones ya crea el nuevo pedido 
    
    IF  
        pendientes >= 5 THEN -- condicion para que tenga menos de 5 pendientes
        SIGNAL SQLSTATE '45000'  -- genera el estado de error, el numero es necesario que el cliente sepa el error
        SET MESSAGE_TEXT = 'Ya cuenta con 5 pedidos pendientes '; -- imprime el mensaje
    
    ELSEIF 
        stockDisponible < cantidad THEN -- condicion para saber si ya no hay stock
        SIGNAL SQLSTATE '45000'-- genera el estado de error, el numero es necesario que el cliente sepa el error
        SET MESSAGE_TEXT = 'Stock agotado'; 

    ELSE
        INSERT INTO Pedidos (fecha_pedido, estado, id_cliente) -- registra el pedido
        VALUES (CURDATE(), 'pendiente', cliente_id); -- devuelve la fecha 

        SET @nuevoPedido_id = last_insert_id(); -- genera un nuevo id

        INSERT INTO Detalles_pedido (cantidad, precio_unitario, id_pedido, id_producto) -- inserta el detalle del pedido
        VALUES (cantidad, precio_unitario, @nuevoPedido_id, producto_id); -- agrega el nuevo id

        UPDATE Productos 
        SET stock = stock - cantidad -- actualiza el nuevo stock
        WHERE id_producto = producto_id; -- se establece la nueva cantidad
    END IF;
    
    
END $$

