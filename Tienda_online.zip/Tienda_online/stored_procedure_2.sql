USE Tienda_online;

-- stored procedure 2

DELIMITER $$

CREATE PROCEDURE RegistrarResenia(
    IN cliente_id INT,
    IN producto_id INT,
    IN calificacion INT,
    IN comentario VARCHAR(1000)
)
BEGIN
    DECLARE compras INT; -- variable local para guardar las compras del cliente

    SELECT COUNT(*) INTO compras -- cuenta los pedidos del cliente 
    FROM Pedidos P -- accede a pedidos con referencia p 
    INNER JOIN Detalles_pedido DP ON P.id_pedido = DP.id_pedido -- une las tablas id del pedido con detalles del pedido
    WHERE P.id_cliente = cliente_id AND DP.id_producto = producto_id; -- verifica que se haya comprado el producto

    IF 
        compras = 0 THEN -- si no hay compras, manda el error 
        SIGNAL SQLSTATE '45000' -- genera el estado de error, el numero es necesario que el cliente sepa el error
        SET MESSAGE_TEXT = 'No puede dar ninuguna resenia, debido a que no ha realizado su compra'; -- imprime el texto
    ELSE
        INSERT INTO Resenias (calificacion, comentario, fecha, id_cliente, id_producto) -- si tiene compras, puede dejar su resenia
        VALUES (calificacion, comentario, CURDATE(), cliente_id, producto_id);  -- se usa curdate para guardar la nueva fecha
    END IF;
END $$

