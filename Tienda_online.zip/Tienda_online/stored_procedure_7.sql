USE Tienda_online;

-- stored procedure 7

DELIMITER $$

CREATE PROCEDURE ActualizarCliente(
    IN p_id_cliente INT,
    IN p_nuevo_telefono INT,
    IN p_nueva_direccion VARCHAR(100)
)
BEGIN
    DECLARE existe INT; -- variable para guardar si el cliente existe
    
    SELECT COUNT(*) INTO existe -- hace un conteo en clientes y si existe lo guarda
    FROM Clientes -- aaccede a tabla clientes 
    WHERE id_cliente = p_id_cliente;

    IF 
        existe = 0 THEN -- si no existe manda el error 
        SIGNAL SQLSTATE '45000'  -- genera el estado de error, el numero es necesario que el cliente sepa el error
        SET MESSAGE_TEXT = 'el cliente que busca, no existe';
        
    ELSE
        IF p_nuevo_telefono IS NOT NULL THEN -- si el telefono no es null se actualiza
            UPDATE Clientes
            SET telefono = p_nuevo_telefono -- se actualiza el nuevo telefono 
            WHERE id_cliente = p_id_cliente;
        END IF;

        IF p_nueva_direccion IS NOT NULL THEN -- si la direccion no es null se actualiza 
            UPDATE Clientes
            SET direccion = p_nueva_direccion -- la dirrecion se actualiza
            WHERE id_cliente = p_id_cliente;
        END IF;
    END IF;
END $$
