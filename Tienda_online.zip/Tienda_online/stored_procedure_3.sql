USE Tienda_online;

-- stored procedure 3


DELIMITER $$

CREATE PROCEDURE ActualizarStock(
    IN producto_id INT,
    IN cantidad INT
)
BEGIN
    DECLARE stock_actual INT; -- variable local que guarda el nuevo stock
    
    SELECT stock INTO stock_actual -- consulta el stock y se guarda 
    FROM Productos -- accede a productos 
    WHERE id_producto = producto_id; -- actualiza el id

    IF 
        stock_actual < cantidad THEN -- disminuimos la cantidad de stock que se quiere tomar, y si no es suficiente manda el error
        SIGNAL SQLSTATE '45000' -- genera el estado de error, el numero es necesario que el cliente sepa el error
        SET MESSAGE_TEXT = 'Stock agotado';
    ELSE
        UPDATE Productos -- si todavia hay stock, se actualiza restando la cantidad vendida
        SET stock = stock - cantidad
        WHERE id_producto = producto_id; -- el producto tiene que coincidir con el id
    END IF;
END $$
