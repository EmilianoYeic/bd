USE Tienda_online;

-- 5 productos con mejor calificacion y resenias 
SELECT p.nombre AS producto, -- selecciona el nombre del producto de la tabla productos 
       AVG(r.calificacion) AS promedio_calificacion, -- calcula la calificacion de las resenias y el promedio de los productos
       COUNT(r.id_resenia) AS total_resenias -- muestra las resenias de cada producto
FROM Productos p -- toma productos con referencia p 
INNER JOIN Resenias r ON p.id_producto = r.id_producto -- une las tablas del id producto y resenias
GROUP BY p.id_producto, p.nombre -- agrupa los productos
ORDER BY promedio_calificacion DESC  -- ordena los productos de mejor al peor
LIMIT 5; -- muestra solo los primeros 5 productos segun el promedio 